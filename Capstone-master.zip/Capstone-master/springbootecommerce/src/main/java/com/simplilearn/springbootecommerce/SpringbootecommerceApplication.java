package com.simplilearn.springbootecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootecommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootecommerceApplication.class, args);
	}

}
